<?php /*a:7:{s:81:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/menu/index.html";i:1550197841;s:83:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/public/_base.html";i:1552891910;s:82:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/public/_top.html";i:1532336685;s:83:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/public/_left.html";i:1552891182;s:82:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/public/_nav.html";i:1532336685;s:85:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/public/_footer.html";i:1532336685;s:85:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/public/_bottom.html";i:1552889067;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>菜单 - 系统管理</title>
    <link rel="stylesheet" type="text/css" href="/static/admin/vendors/bootstrap/dist/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/nprogress/nprogress.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/bootstrap-daterangepicker/daterangepicker.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/iCheck/skins/flat/green.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/google-code-prettify/bin/prettify.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/select2/dist/css/select2.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/switchery/dist/switchery.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/vendors/starrr/dist/starrr.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/build/css/custom.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/Lobibox.min.css" />
<script type="text/javascript" src="/static/ueditor/ueditor.config.js"></script>
<script type="text/javascript" src="/static/ueditor/ueditor.all.js"></script>
<script type="text/javascript" src="/static/ueditor/lang/zh-cn/zh-cn.js"></script>
    <style type="text/css">
    table {
        table-layout: fixed;
    }

    td {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
    .editor_column{
        color: #0088cc;
        display: inline-block;
        border-bottom: dashed 1px #0088cc;
        cursor: pointer;
    }

    .layui-layer-content{
       height: 250px;
    }

    .btn-default.active{
        background-color: #f0ad4e;
        color: #000;
    }

    ._current-page {
        background: rgba(255,255,255,.05);
    }
    ._current-page a {
        color: #fff!important;
    }
    </style>
</head>
<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a href="/admin" class="site_title">
                <!--<img style="width: 50px;height: 50px;" src="/uploads/img/admin_avatar/20180710/7d961483129e447da5a2566bd93a6b5a.png">-->
                <span><?php echo Env::get('admin_conf.title'); ?>系统</span></a>
        </div>

        <div class="clearfix"></div>

        <!-- menu profile quick info -->
        <div class="profile clearfix">
            <div class="profile_pic">
                <img src="<?php echo htmlentities($adminUser['admin_info']['avatar']); ?>" alt="..." class="img-circle profile_img">
            </div>
            <div class="profile_info">
                <span>欢迎,</span>
                <h2><?php echo isset($adminUser['admin_info']['nickname']) ? htmlentities($adminUser['admin_info']['nickname']) : htmlentities($adminUser['name']); ?></h2>
            </div>
        </div>
        <!-- /menu profile quick info -->

        <br/>

        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <ul class="nav side-menu">
                    <?php foreach($menus as $vo): ?>
                    <li class=''><a><i class="fa <?php echo $vo['icon']?$vo['icon']:'fa-home'; ?>"></i> <?php echo htmlentities($vo['name']); ?> <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <?php foreach($vo['children'] as $v): ?>
                            <li><a href="/<?php echo htmlentities($v['module']); ?>/<?php echo htmlentities($v['controller']); ?>/<?php echo htmlentities($v['action']); ?><?php echo $v['params']?'?'.$v['params']:''; ?>"><?php echo htmlentities($v['name']); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
        <!-- /sidebar menu -->

        <!-- /menu footer buttons -->
        <div class="sidebar-footer hidden-small">
            <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo htmlentities(app('config')->get('admin.layout_url')); ?>">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
            </a>
        </div>
        <!-- /menu footer buttons -->
    </div>
</div>
        <!-- top navigation -->
        <div class="top_nav">
    <div class="nav_menu">
        <nav>
            <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li class="">
                    <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown"
                       aria-expanded="false">
                        <img src="<?php echo htmlentities($adminUser['admin_info']['avatar']); ?>" alt=""><?php echo isset($adminUser['admin_info']['nickname']) ? htmlentities($adminUser['admin_info']['nickname']) : htmlentities($adminUser['name']); ?>
                        <span class=" fa fa-angle-down"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-usermenu pull-right">
                        <li>
                            <a onclick="pageTable('设置','/admin/admin/edit','<?php echo htmlentities($adminUser['id']); ?>');">
                                <span>设置</span>
                            </a>
                            <a  onclick='pageTable("管理员详情","/admin/admin/detail","<?php echo htmlentities($adminUser['id']); ?>",600);'>
                                <span>个人信息</span>
                            </a>
                        </li>
                        <li><a href="<?php echo htmlentities(app('config')->get('admin.layout_url')); ?>"><i class="fa fa-sign-out pull-right"></i>退出</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</div>
        <!-- /top navigation -->
        <!-- page content -->
        

<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>菜单列表</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <!--<li><a onclick="deleteData('deleteType');">删除</a>-->
                            <li>
                                <?php echo authAction('/'.MODULE_NAME.'/'.CONTROLLER_NAME.'/add', '添加菜单','add',true,'',700); ?>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>

                    <div class="x_content">
                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action">
                                <thead>
                                <tr class="headings">
                                    <th class="column-title"  style="width: 5%">Id</th>
                                    <th class="column-title"  style="width: 22%">名称</th>
                                    <th class="column-title">模块</th>
                                    <th class="column-title">控制器</th>
                                    <th class="column-title">方法名</th>
                                    <th class="column-title">参数</th>
                                    <th class="column-title">状态</th>
                                    <th class="column-title">是否显示</th>
                                    <th class="column-title">创建时间</th>
                                    <th class="column-title">修改时间</th>
                                    <th class="column-title">操作管理</th>
                                </tr>

                                </thead>
                                <tbody>
                                <?php foreach($data as $vo): ?>
                                <tr class="even pointer">
                                    <td><?php echo htmlentities($vo['id']); ?></td>
                                    <td>
                                        <?php echo str_repeat('-', 8*$vo['level']).$vo['name']; ?>
                                    </td>
                                    <td><?php echo htmlentities($vo['module']); ?></td>
                                    <td><?php echo htmlentities($vo['controller']); ?></td>
                                    <td><?php echo htmlentities($vo['action']); ?></td>
                                    <td><?php echo htmlentities($vo['params']); ?></td>
                                    <td><?php echo $vo['status']==1 ? '正常' : '禁用'; ?></td>
                                    <td><?php echo $vo['is_show']==1 ? '是' : '否'; ?></td>
                                    <td><?php echo htmlentities($vo['create_time']); ?></td>
                                    <td><?php echo htmlentities($vo['update_time']); ?></td>
                                    <td>
                                        <p class="url">
                                            <?php echo authAction('/'.MODULE_NAME.'/'.CONTROLLER_NAME.'/edit', '修改菜单','edit',true,$vo['id']); ?>
                                        </p>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php echo $page; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->

        <!-- /page content -->
        <!-- footer content -->
        <footer>
    <div class="pull-right">
       Contact <a href="#"><?php echo Env::get('admin_conf.title'); ?></a>
    </div>
    <div class="clearfix"></div>
</footer>
        <!-- /footer content -->
    </div>
</div>

<script type="text/javascript" src="/static/admin/vendors/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/fastclick/lib/fastclick.js"></script>
<script type="text/javascript" src="/static/admin/vendors/nprogress/nprogress.js"></script>
<script type="text/javascript" src="/static/admin/vendors/iCheck/icheck.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/Chart.js/dist/Chart.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/moment/min/moment.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="/static/admin/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
<!-- Select2 -->
<script type="text/javascript" src="/static/admin/vendors/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/raphael/raphael.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/morris.js/morris.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/gauge.js/dist/gauge.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/skycons/skycons.js"></script>
<script type="text/javascript" src="/static/admin/vendors/Flot/jquery.flot.js"></script>
<script type="text/javascript" src="/static/admin/vendors/Flot/jquery.flot.pie.js"></script>
<script type="text/javascript" src="/static/admin/vendors/Flot/jquery.flot.time.js"></script>
<script type="text/javascript" src="/static/admin/vendors/Flot/jquery.flot.stack.js"></script>
<script type="text/javascript" src="/static/admin/vendors/Flot/jquery.flot.resize.js"></script>
<script type="text/javascript" src="/static/admin/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script type="text/javascript" src="/static/admin/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script type="text/javascript" src="/static/admin/vendors/flot.curvedlines/curvedLines.js"></script>
<script type="text/javascript" src="/static/admin/vendors/DateJS/build/date.js"></script>
<script type="text/javascript" src="/static/admin/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/static/admin/build/js/custom.min.js"></script>
<script type="text/javascript" src="/static/admin/common.js"></script>
<script type="text/javascript" src="/static/admin/common_data.js"></script>
<script type="text/javascript" src="/static/admin/common_image.js"></script>
<script type="text/javascript" src="/static/admin/common_video.js"></script>

<script type="text/javascript" src="/static/admin/echarts.common.min.js"></script>
<script type="text/javascript" src="/static/admin/lobibox.min.js"></script>
<script type="text/javascript" src="/static/admin/layer/layer.js"></script>
<script>
    $('.collapse-search').click(function () {
        window.location.href = '<?php echo url(); ?>?'+$('.searchFrom').serialize();
    });
    $('.collapse-reset').click(function () {
        $(':input','.searchFrom')
            .not(':button,:submit,:reset,:hidden')
            .val('')
            .removeAttr('checked')
            .removeAttr('selected');
        window.location.href = '<?php echo url(); ?>?'+$('.searchFrom').serialize();
    });

    $('.collapse-export').click(function () {
        window.location.href = $(this).data('url')+'?'+$('.searchFrom').serialize();
    });

    $('#jumpPage').on('click', function(){
        location.href = location.href.split('?')[0]+"?page="+$('#pageNum').val();
    })
</script>





</body>
</html>