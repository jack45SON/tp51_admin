<?php /*a:1:{s:83:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/admin/detail.html";i:1552549632;}*/ ?>

<div class="right_col" role="main">
    <div class="">
        <div class="row">
            <div class="x_panel">
                <div class="x_content">
                    <br/>
                    <form class="form-horizontal" method="post" action=""
                          onsubmit="return AddEditFrom(this,'/admin/admin/detail',true)">
                        <input type="hidden" class="form-control" value="<?php echo htmlentities($data['id']); ?>" name="id"/>
                        <input type="hidden" class="form-control" value="<?php echo htmlentities($id); ?>" name="admin_id"/>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3"><?php echo htmlentities(app('lang')->get('nickname')); ?></label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                                <input type="text" class="form-control" name="nickname"
                                       value="<?php echo htmlentities($data['nickname']); ?>" required
                                       data-msg="昵称" placeholder="昵称"/>
                                <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo htmlentities(app('lang')->get('sex')); ?></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div id="sex" class="btn-group" data-toggle="buttons">
                                    <label class='btn btn-default <?php if($data['sex'] == '0'): ?> active <?php endif; ?>' data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                        <input type="radio" name="sex" value="0"<?php if($data['sex'] == '0'): ?> checked <?php endif; ?>> &nbsp; <?php echo htmlentities(app('lang')->get('sex0')); ?> &nbsp;
                                    </label>
                                    <label class='btn btn-default <?php if($data['sex'] == '1'): ?> active <?php endif; ?>' data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                        <input type="radio" name="sex" value="1" <?php if($data['sex'] == '1'): ?> checked <?php endif; ?>> <?php echo htmlentities(app('lang')->get('sex1')); ?>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3"><?php echo htmlentities(app('lang')->get('mobile')); ?></label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                                <input type="number" class="form-control" id="mobile"
                                       value="<?php echo htmlentities($data['mobile']); ?>" name="mobile" placeholder="<?php echo htmlentities(app('lang')->get('mobile')); ?>">

                                <span class="fa fa-envelope form-control-feedback right" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3"><?php echo htmlentities(app('lang')->get('email')); ?></label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                                <input type="text" class="form-control" id="email"
                                       value="<?php echo htmlentities($data['email']); ?>" name="email" placeholder="<?php echo htmlentities(app('lang')->get('email')); ?>">
                                <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3"><?php echo htmlentities(app('lang')->get('qq')); ?></label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                                <input type="number" class="form-control" id="qq"
                                       value="<?php echo htmlentities($data['qq']); ?>" name="qq" placeholder="<?php echo htmlentities(app('lang')->get('qq')); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3"><?php echo htmlentities(app('lang')->get('avatar')); ?></label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                                <?php if($data['avatar']): ?>
                                <input type="text" class="form-control" value="<?php echo htmlentities($data['avatar']); ?>" name="avatar" readonly
                                       onclick="uploadImgOne(this);" placeholder="选择图片" required data-msg="<?php echo htmlentities(app('lang')->get('avatar')); ?>"/>
                                <input type="hidden" class="form-control attach_id" value="<?php echo htmlentities($data['attach_id']); ?>" name="attach_id" />
                                <span class="fa fa-folder form-control-feedback right" aria-hidden="true"></span>
                                <p class="m-top-sm" style="margin-top: 10px;">
                                    <img src="<?php echo htmlentities($data['avatar']); ?>" width="120"/>
                                </p>
                                <?php else: ?>
                                <input type="text" class="form-control" value="<?php echo htmlentities($data['avatar']); ?>" name="avatar" readonly
                                       onclick="uploadImgOne(this);" placeholder="选择图片"/>
                                <input type="hidden" class="form-control attach_id" value="<?php echo htmlentities($data['attach_id']); ?>" name="attach_id"/>
                                <span class="fa fa-folder form-control-feedback right" aria-hidden="true"></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-3"></label>
                            <div class="col-md-9 col-md-offset-3">
                                <button type="reset" class="btn btn-primary"><?php echo htmlentities(app('lang')->get('reset')); ?></button>
                                <button type="submit" class="btn btn-success"><?php echo htmlentities(app('lang')->get('submit')); ?></button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


