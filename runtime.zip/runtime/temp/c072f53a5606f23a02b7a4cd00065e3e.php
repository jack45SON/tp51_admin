<?php /*a:1:{s:80:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/admin/add.html";i:1550197685;}*/ ?>
<div class="right_col" role="main">
    <div class="">
        <div class="row">
            <div class="x_panel">
                <div class="x_content">
                    <br/>
                    <form class="form-horizontal" method="post" action=""  onsubmit="return AddEditFrom(this,'/admin/admin/add',true);">
                        <div class="item form-group">
                            <label class="control-label col-md-3" for="name"><?php echo htmlentities(app('lang')->get('name')); ?><span
                                    class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" class="form-control col-md-7 col-xs-12" name="name" required="required" type="text">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="password" class="control-label col-md-3"><?php echo htmlentities(app('lang')->get('password')); ?><span
                                    class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="password" type="password" name="password"
                                       class="form-control col-md-7 col-xs-12" required="required">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="res_password"
                                   class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo htmlentities(app('lang')->get('res_password')); ?><span
                                    class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="res_password" type="password" name="res_password"
                                       class="form-control col-md-7 col-xs-12" required="required">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="group_ids" class="control-label col-md-3"><?php echo htmlentities(app('lang')->get('group')); ?></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="group_ids"class="form-control js-example-basic-multiple" name="group_ids[]" required  multiple="multiple">
                                    <?php foreach($group as $vo): ?>
                                    <option value="<?php echo htmlentities($vo['id']); ?>" data-id="<?php echo htmlentities($vo['id']); ?>">
                                    <?php echo htmlentities($vo['title']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="reset" class="btn btn-primary"><?php echo htmlentities(app('lang')->get('reset')); ?></button>
                                <button type="submit"  class="btn btn-success"><?php echo htmlentities(app('lang')->get('submit')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    $(function () {
        $(document).ready(function() {
            $('.js-example-basic-multiple').select2();
        });
    });
</script>
