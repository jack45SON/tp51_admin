<?php /*a:1:{s:81:"/Users/jackson/wwwroot/mineblog/tp51_admin/application/admin/view/group/edit.html";i:1552881000;}*/ ?>
<div class="right_col" role="main">
    <div class="">
        <div class="row">
            <div class="x_panel">
                <div class="x_content">
                    <br/>
                    <form class="form-horizontal" method="post" action=""  onsubmit="return AddEditFrom(this,'/admin/Group/edit',true);">
                        <input type="hidden" name="id" value="<?php echo htmlentities($data['id']); ?>">
                        <div class="item form-group">
                            <label class="control-label col-md-3" for="name"><?php echo htmlentities(app('lang')->get('name')); ?><span
                                    class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" class="form-control col-md-7 col-xs-12" name="name"
                                    value="<?php echo htmlentities($data['name']); ?>"   required="required" type="text">
                            </div>
                        </div>
                        <div class="item form-group">
                            <label for="desc"
                                   class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo htmlentities(app('lang')->get('desc')); ?></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="desc" type="text" name="desc"  value="<?php echo htmlentities($data['desc']); ?>"
                                       class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo htmlentities(app('lang')->get('status')); ?></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div id="status" class="btn-group" data-toggle="buttons">
                                    <label class='btn btn-default <?php if($data['status'] == '0'): ?> active <?php endif; ?>' data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                        <input type="radio" name="status" value="0"<?php if($data['status'] == '0'): ?> checked <?php endif; ?>> &nbsp; <?php echo htmlentities(app('lang')->get('status0')); ?> &nbsp;
                                    </label>
                                    <label class='btn btn-primary <?php if($data['status'] == '1'): ?> active <?php endif; ?>' data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                        <input type="radio" name="status" value="1" <?php if($data['status'] == '1'): ?> checked <?php endif; ?>> <?php echo htmlentities(app('lang')->get('status1')); ?>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="reset" class="btn btn-primary"><?php echo htmlentities(app('lang')->get('reset')); ?></button>
                                <button type="submit"  class="btn btn-success"><?php echo htmlentities(app('lang')->get('submit')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
